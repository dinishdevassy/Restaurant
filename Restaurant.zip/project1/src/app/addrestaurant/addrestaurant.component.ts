import { Component, OnInit } from '@angular/core';
import {RestaurantService} from '../restaurant.service';
import {Router} from '@angular/router';
import { RestaurantModel } from 'src/models/restaurant.model';
import { FileUploader } from 'ng2-file-upload';

@Component({
  selector: 'app-addrestaurant',
  templateUrl: './addrestaurant.component.html',
  styleUrls: ['./addrestaurant.component.css']
})
export class AddrestaurantComponent implements OnInit {
  public uploader:FileUploader=new FileUploader({
    url:'http://localhost:8080/admin/add',
    method:'POST',
    itemAlias:"photo"
  });
  constructor(
    private rs:RestaurantService,
    private rt:Router
    ) { }
  image;
  restaurant=new RestaurantModel(null,null,null,null,null,null,null,null);

  ngOnInit() {

   this.uploader.onAfterAddingFile=(file)=>{
     file.withCredentials=false;
   }
  }
  addrestaurant(){
    // console.log(this.restaurant)
    
    this.uploader.onBuildItemForm=(file:any,form:any)=>{
      form.append('name',this.restaurant.name);
      form.append('city',this.restaurant.city);
      form.append('star',this.restaurant.star);
      form.append('opentime',this.restaurant.opentime);
      form.append('closetime',this.restaurant.closetime);
      form.append('address',this.restaurant.address);
      form.append('phno',this.restaurant.phno);
    }
    this.uploader.uploadAll();


    //this.rt.navigateByUrl("/view");




    // this.rs.newrestaurant(this.restaurant).subscribe(data=>{
    //   alert(JSON.parse(JSON.stringify(data)).msg);
    // })
  }
}
