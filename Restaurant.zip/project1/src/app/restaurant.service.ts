import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { RestaurantModel } from 'src/models/restaurant.model';
import { booktableModel } from 'src/models/booktable.model';
@Injectable({
  providedIn: 'root'
})
export class RestaurantService {

  constructor(private hc:HttpClient) { }

  public newrestaurant(restaurant:RestaurantModel){
    let url="http://localhost:8080/admin/add";
    return this.hc.post(url,{restaurant})

  }

  public viewrestaurant(){
    let url="http://localhost:8080/admin/view";
    return this.hc.get(url)
  }

  public removerestaurant(rid){
    console.log(rid);
    let url="http://localhost:8080/admin/delete/"+rid;
    return this.hc.get(url);
  }
  public searchview(sData){
    
    let url="http://localhost:8080/admin/searchview";
    return this.hc.post(url,sData); 
  }

  public reservetable(booktable:booktableModel){
    // console.log(booktable);
    
    let url="http://localhost:8080/user/add";
    return this.hc.post(url,{booktable})

  }

  public detailView(id){
    
    let url="http://localhost:8080/user/detailView/"+id;
    return this.hc.get(url); 
  }
}
