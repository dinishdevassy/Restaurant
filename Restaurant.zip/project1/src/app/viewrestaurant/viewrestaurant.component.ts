import { Component, OnInit } from '@angular/core';
import {RestaurantService} from '../restaurant.service';
import {Router} from '@angular/router';
import { RestaurantModel } from 'src/models/restaurant.model';
import { importExpr } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-viewrestaurant',
  templateUrl: './viewrestaurant.component.html',
  styleUrls: ['./viewrestaurant.component.css']
})
export class ViewrestaurantComponent implements OnInit {
  public image:String;
  restaurant=new RestaurantModel(null,null,null,null,null,null,null,null);
  result;
  sname;
  scity;
  sstar;
  constructor(private rs:RestaurantService,private rt:Router) { }

  ngOnInit() {
          // this.image=new Image("/project1/src/assets/images/download.jpg");
      this.viewrestaurant();
  }
  public clear(){
    this.sname="";
    this.scity="";
    this.sstar="";
    this.viewrestaurant();
  }
  public deleterestaurant(id){
    // console.log(id);
    
    this.rs.removerestaurant(id).subscribe(data=>{
      alert(JSON.parse(JSON.stringify(data)).msg);
      // this.restaurant=JSON.parse(JSON.stringify(data));
    })
    this.rt.navigateByUrl("/view");
  }
  public detailView(id){

      this.rt.navigateByUrl("/detailview/"+id);

  }
  public viewrestaurant(){
    this.rs.viewrestaurant().subscribe(data=>{
      this.restaurant=JSON.parse(JSON.stringify(data));
      console.log(this.restaurant);
      this.result=this.restaurant;
    })
  }
  public searchview(){

    let searchData={
      sname:this.sname,
      scity:this.scity,
      sstar:this.sstar
    };
    this.rs.searchview(searchData).subscribe(data=>{
      this.restaurant=JSON.parse(JSON.stringify(data));
      console.log(this.restaurant);
      this.result=this.restaurant;
    })
  }

}
