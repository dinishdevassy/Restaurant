import { Component, OnInit } from '@angular/core';
import {RestaurantService} from '../restaurant.service';
import {Router} from '@angular/router';
import { RestaurantModel } from 'src/models/restaurant.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private rs:RestaurantService,private rt:Router) { }

  ngOnInit() {
  }

}
