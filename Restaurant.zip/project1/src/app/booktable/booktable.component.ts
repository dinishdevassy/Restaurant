import { Component, OnInit } from '@angular/core';
import {RestaurantService} from '../restaurant.service';
import {Router} from '@angular/router';
import { RestaurantModel } from 'src/models/restaurant.model';
import { booktableModel } from 'src/models/booktable.model'

@Component({
  selector: 'app-booktable',
  templateUrl: './booktable.component.html',
  styleUrls: ['./booktable.component.css']
})
export class BooktableComponent implements OnInit {

  constructor(private rs:RestaurantService,private rt:Router) { }

  booktable=new booktableModel(null,null,null,null,null,null,null)

  ngOnInit() {
  }

  public reservetable(){
    this.rs.reservetable(this.booktable).subscribe(data=>{
      alert(JSON.parse(JSON.stringify(data)).msg);
    })
  }
}
