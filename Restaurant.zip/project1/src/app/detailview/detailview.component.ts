import { Component, OnInit } from '@angular/core';
import {RestaurantService} from '../restaurant.service';
import {Router,ActivatedRoute} from '@angular/router';
import { RestaurantModel } from 'src/models/restaurant.model';

@Component({
  selector: 'app-detailview',
  templateUrl: './detailview.component.html',
  styleUrls: ['./detailview.component.css']
})
export class DetailviewComponent implements OnInit {
  restaurant=new RestaurantModel(null,null,null,null,null,null,null,null);
  result;
  constructor(private rt:Router,private rs:RestaurantService,private ar:ActivatedRoute) { }
id;
  ngOnInit() {
    this.id=this.ar.snapshot.paramMap.get("id");
    console.log(this.id);
        this.rs.detailView(this.id).subscribe(data=>{
      this.restaurant=JSON.parse(JSON.stringify(data));
      console.log(this.restaurant);
      this.result=this.restaurant;
  })
  }


}
