import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {RouterModule,Routes} from '@angular/router';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
//import {app} from './app-routing.module';
import {RestaurantService} from './restaurant.service'
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { AddrestaurantComponent } from './addrestaurant/addrestaurant.component';
import { ViewrestaurantComponent } from './viewrestaurant/viewrestaurant.component';
import { FooterComponent } from './footer/footer.component';
import { DetailviewComponent } from './detailview/detailview.component';
import { BooktableComponent } from './booktable/booktable.component';
import { FileUploadModule } from 'ng2-file-upload';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';

const approutes:Routes=[
  {path:"new",component:AddrestaurantComponent},
  {path:"view",component:ViewrestaurantComponent},
  {path:"book",component:BooktableComponent},
  {path:"home",component:LoginComponent},
  {path:"detailview/:id",component:DetailviewComponent}
  
];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    AddrestaurantComponent,
    ViewrestaurantComponent,
    FooterComponent,
    DetailviewComponent,
    BooktableComponent,
    LoginComponent,
    RegisterComponent,
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(approutes),
    FormsModule,
    HttpClientModule,
    FileUploadModule
  ],
  providers: [RestaurantService],
  bootstrap: [AppComponent]
})
export class AppModule { }
