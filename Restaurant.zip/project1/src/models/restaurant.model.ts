export class RestaurantModel{
    constructor(
        public name,
        public city,
        public star,
        public opentime,
        public closetime,
        public address,
        public phno,
        public image

    ){}
}