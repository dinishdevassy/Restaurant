export class booktableModel{
    constructor(
        public name,
        public address,
        public phno,
        public gno,
        public dt,
        public tm,
        public dy,

    ){}
}